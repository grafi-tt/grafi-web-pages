#!/usr/bin/ruby

require 'nkf'

SKKIME = Proc.new{
  hira = $2.dup
  kata = NKF.nkf('-W -w --katakana', hira)
  if $3
    $3.empty? ? mode = 2 : (mode,kata = 1,$3.dup)
  else
    hira == kata ? mode = 2 : mode = 1
  end

  roma = $1.sub(/\\/, '\\\\\\\\')

  if mode == 1
    "1#{roma}\\0\\00\\0#{hira}\\0#{kata}\\0"
  else # mode == 2
    "2#{roma}\\0\\00\\0#{hira}\\0"
  end
}
UIMSKK = Proc.new{
  result = $2.each_char.map{|c| %Q!("#{c}" "#{NKF.nkf('-W -w --katakana', c)}" "#{NKF.nkf('-W -w -Z4', NKF.nkf('-W -w --katakana', c))}")! }.join(' ')

  roma = $1.each_char.map{|c|%Q!"#{c}"!}.join(' ').sub(/\\/, '\\\\\\\\')

  "(((#{roma}). ())(#{result}))"
}
SCIMSKK = Proc.new{
  "#$1#{' '*(6-$1.length)}= #$2"
}
block=SCIMSKK

# subの間違った使い方. ブロック万歳!
while gets
  $_.sub!(/^([^\t\n#][^\t\n]*)\t([^\t\n]+)(?:\t([^\t\n]*))??$/, &block) && print # 置換が有った時のみ出力
end
